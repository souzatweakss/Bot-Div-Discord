import discord
from discord.ext import commands
import asyncio
import os
from colorama import init, Fore, Style
import pkg_resources
import sys

# Inicializa o colorama para cores no console
init()

# Função para verificar a versão do discord.py-self
def check_discord_version():
    try:
        version = pkg_resources.get_distribution("discord.py-self").version
        print(f"{Fore.WHITE}Versão do discord.py-self: {version}{Style.RESET_ALL}")
        return version
    except pkg_resources.DistributionNotFound:
        print(f"{Fore.WHITE}Erro: discord.py-self não está instalado.{Style.RESET_ALL}")
        sys.exit(1)

# Função para obter o diretório do script
def get_script_dir():
    if getattr(sys, 'frozen', False):
        # Executável compilado com PyInstaller
        return os.path.dirname(sys.executable)
    else:
        # Script Python
        return os.path.dirname(os.path.abspath(__file__))

# Função para ler tokens do arquivo tokens.txt
def get_tokens():
    script_dir = get_script_dir()
    tokens_file = os.path.join(script_dir, "tokens.txt")
    if not os.path.exists(tokens_file):
        print(f"{Fore.WHITE}Erro: Arquivo 'tokens.txt' não encontrado em {tokens_file}.{Style.RESET_ALL}")
        return []
    try:
        with open(tokens_file, "r", encoding="utf-8") as f:
            tokens = [line.strip() for line in f if line.strip()]
        if not tokens:
            print(f"{Fore.WHITE}Erro: Nenhum token encontrado em 'tokens.txt'.{Style.RESET_ALL}")
            return []
        return tokens
    except Exception as e:
        print(f"{Fore.WHITE}Erro ao ler 'tokens.txt': {e}.{Style.RESET_ALL}")
        return []

# Função para ler a mensagem do arquivo message.txt
def get_message():
    script_dir = get_script_dir()
    message_file = os.path.join(script_dir, "message.txt")
    if not os.path.exists(message_file):
        print(f"{Fore.WHITE}Erro: Arquivo 'message.txt' não encontrado em {message_file}.{Style.RESET_ALL}")
        return None
    try:
        with open(message_file, "r", encoding="utf-8") as f:
            message = f.read().strip()
        if not message:
            print(f"{Fore.WHITE}Erro: O arquivo 'message.txt' está vazio.{Style.RESET_ALL}")
            return None
        if len(message) > 2000:
            print(f"{Fore.WHITE}Erro: A mensagem excede o limite de 2000 caracteres do Discord.{Style.RESET_ALL}")
            return None
        return message
    except Exception as e:
        print(f"{Fore.WHITE}Erro ao ler 'message.txt': {e}.{Style.RESET_ALL}")
        return None

# Configura intents com fallback
def setup_intents():
    try:
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        intents.members = True
        if not intents.members:
            print(f"{Fore.WHITE}Aviso: Intent 'members' não está ativado. Pode limitar a lista de membros.{Style.RESET_ALL}")
        return intents
    except AttributeError:
        print(f"{Fore.WHITE}Aviso: Intents não suportados nesta versão do discord.py-self. Usando configuração mínima.{Style.RESET_ALL}")
        return None

intents = setup_intents()

# Função para limpar a tela
def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")

# Função para enviar mensagens aos membros do servidor usando um token
async def send_messages_for_token(token, guild_id, message):
    try:
        # Inicializa um novo cliente para o token
        bot = commands.Bot(command_prefix='!', self_bot=True, intents=intents)
        success_count = 0
        failed_count = 0

        @bot.event
        async def on_ready():
            nonlocal success_count, failed_count
            try:
                print(f"{Fore.MAGENTA}Token {token[:10]}...: Conectado como {bot.user.name}#{bot.user.discriminator}{Style.RESET_ALL}")
                guild = bot.get_guild(int(guild_id))
                if not guild:
                    print(f"{Fore.WHITE}Erro: Servidor {guild_id} não encontrado para token {token[:10]}...{Style.RESET_ALL}")
                    await bot.close()
                    return

                # Tenta carregar todos os membros
                members = []
                try:
                    async for member in guild.fetch_members(limit=None):
                        if member != bot.user:
                            members.append(member)
                except discord.errors.Forbidden:
                    print(f"{Fore.WHITE}Erro: Token {token[:10]}... não tem permissão para acessar membros.{Style.RESET_ALL}")
                    members = [member for member in guild.members if member != bot.user]

                if not members:
                    print(f"{Fore.WHITE}Erro: Nenhum membro encontrado no servidor para token {token[:10]}...{Style.RESET_ALL}")
                    await bot.close()
                    return

                print(f"{Fore.MAGENTA}Token {token[:10]}...: Enviando mensagens para {len(members)} membros...{Style.RESET_ALL}")
                for member in members:
                    try:
                        await member.send(message)
                        print(f"{Fore.MAGENTA}Token {token[:10]}...: Mensagem enviada para {member.name}#{member.discriminator}.{Style.RESET_ALL}")
                        success_count += 1
                        await asyncio.sleep(2)  # Atraso maior para evitar rate limits
                    except discord.errors.Forbidden:
                        print(f"{Fore.WHITE}Token {token[:10]}...: Não foi possível enviar mensagem para {member.name}#{member.discriminator} (DMs fechados ou bloqueado).{Style.RESET_ALL}")
                        failed_count += 1
                        await asyncio.sleep(2)
                    except discord.errors.HTTPException as e:
                        if e.status == 429:
                            retry_after = e.retry_after if hasattr(e, 'retry_after') else 5
                            print(f"{Fore.WHITE}Token {token[:10]}...: Rate limit atingido. Aguardando {retry_after} segundos...{Style.RESET_ALL}")
                            await asyncio.sleep(retry_after)
                            continue
                        else:
                            print(f"{Fore.WHITE}Token {token[:10]}...: Erro ao enviar mensagem para {member.name}#{member.discriminator}: {e}.{Style.RESET_ALL}")
                            failed_count += 1
                            await asyncio.sleep(2)
                    except Exception as e:
                        print(f"{Fore.WHITE}Token {token[:10]}...: Erro inesperado ao enviar mensagem para {member.name}#{member.discriminator}: {e}.{Style.RESET_ALL}")
                        failed_count += 1
                        await asyncio.sleep(2)

                print(f"{Fore.MAGENTA}Token {token[:10]}...: Envio concluído! Sucessos: {success_count}, Falhas: {failed_count}.{Style.RESET_ALL}")
            except Exception as e:
                print(f"{Fore.WHITE}Token {token[:10]}...: Erro inesperado: {e}.{Style.RESET_ALL}")
            finally:
                await bot.close()

        await bot.start(token)
        return success_count, failed_count
    except discord.errors.LoginFailure:
        print(f"{Fore.WHITE}Erro: Token inválido {token[:10]}...{Style.RESET_ALL}")
        return 0, 0
    except Exception as e:
        print(f"{Fore.WHITE}Erro ao processar token {token[:10]}...: {e}.{Style.RESET_ALL}")
        return 0, 0

# Função principal para enviar mensagens com múltiplos tokens em paralelo
async def send_messages_to_all():
    try:
        tokens = get_tokens()
        if not tokens:
            await asyncio.sleep(1)
            return

        message = get_message()
        if not message:
            await asyncio.sleep(1)
            return

        guild_id = input(f"{Fore.MAGENTA}Digite o ID do servidor (ou 'cancelar'): {Style.RESET_ALL}").strip()
        if guild_id.lower() == "cancelar":
            return

        print(f"{Fore.MAGENTA}Iniciando envio de mensagens com {len(tokens)} tokens em paralelo...{Style.RESET_ALL}")
        # Executa todos os tokens em paralelo com asyncio.gather
        results = await asyncio.gather(
            *(send_messages_for_token(token, guild_id, message) for token in tokens),
            return_exceptions=True
        )

        total_success = 0
        total_failed = 0
        valid_tokens = 0

        for i, result in enumerate(results):
            if isinstance(result, tuple):
                success, failed = result
                total_success += success
                total_failed += failed
                if success > 0 or failed > 0:
                    valid_tokens += 1
            else:
                print(f"{Fore.WHITE}Erro ao processar token {tokens[i][:10]}...: {result}{Style.RESET_ALL}")

        print(f"{Fore.MAGENTA}Processo concluído! Tokens válidos: {valid_tokens}/{len(tokens)}, Mensagens enviadas: {total_success}, Falhas: {total_failed}.{Style.RESET_ALL}")
        await asyncio.sleep(1)

    except ValueError:
        print(f"{Fore.WHITE}Erro: Entrada inválida (verifique o ID do servidor).{Style.RESET_ALL}")
        await asyncio.sleep(1)
    except Exception as e:
        print(f"{Fore.WHITE}Erro inesperado: {e}.{Style.RESET_ALL}")
        await asyncio.sleep(1)

# Menu principal
def display_menu():
    clear_screen()
    try:
        import shutil
        window_width = shutil.get_terminal_size().columns
    except (NameError, ImportError):
        window_width = 80  # Fallback para largura padrão
    banner_lines = [
        f"{Fore.MAGENTA}=== Self-Bot: Enviar Mensagens para Todos os Membros (Múltiplos Tokens) ===",
        "",
        f"{Fore.MAGENTA}[ {Fore.WHITE}1 {Fore.MAGENTA}] {Fore.WHITE}Enviar mensagens para todos os membros",
        f"{Fore.MAGENTA}[ {Fore.WHITE}2 {Fore.MAGENTA}] {Fore.WHITE}Sair",
    ]
    for line in banner_lines:
        clean_line = line.replace(Fore.MAGENTA, '').replace(Fore.WHITE, '').replace(Style.RESET_ALL, '')
        padding = (window_width - len(clean_line)) // 2
        centered_line = ' ' * padding + line
        print(centered_line)

async def main_menu():
    check_discord_version()
    while True:
        display_menu()
        choice = input(f"{Fore.MAGENTA}> {Style.RESET_ALL}").strip()
        try:
            if choice == "1":
                await send_messages_to_all()
            elif choice == "2":
                print(f"{Fore.WHITE}Saindo...{Style.RESET_ALL}")
                break
            else:
                print(f"{Fore.WHITE}Opção inválida!{Style.RESET_ALL}")
                await asyncio.sleep(1)
        except Exception as e:
            print(f"{Fore.WHITE}Erro na execução: {e}. Tente novamente.{Style.RESET_ALL}")
            await asyncio.sleep(1)

if __name__ == "__main__":
    try:
        asyncio.run(main_menu())
    except KeyboardInterrupt:
        print(f"{Fore.WHITE}Programa interrompido pelo usuário.{Style.RESET_ALL}")
    except Exception as e:
        print(f"{Fore.WHITE}Erro ao iniciar o programa: {e}{Style.RESET_ALL}")
